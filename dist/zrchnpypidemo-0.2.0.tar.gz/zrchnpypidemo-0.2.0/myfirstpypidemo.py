__version__ = '0.2.0'

def print_hello():
    print('hello world')

def print_hello_v2():
    print('hello world v0.2.0')

if __name__ == '__main__':
    pass

