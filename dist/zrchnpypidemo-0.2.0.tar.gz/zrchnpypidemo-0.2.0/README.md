# MyFirstPypiDemo
OK, Let me just say something.