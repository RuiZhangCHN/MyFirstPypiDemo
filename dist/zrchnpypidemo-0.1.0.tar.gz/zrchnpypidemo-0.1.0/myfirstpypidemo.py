__version__ = '0.1.0'

def print_hello():
    print('hello world')

if __name__ == '__main__':
    main()

    